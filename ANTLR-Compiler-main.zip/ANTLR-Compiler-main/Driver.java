/*ANTLR Driver for Construction of Language Translators
**Created By Nicholas Duncan, Furio Gerwitz, and Will Marriott
**References:
**Definitive ANTLR4 Reference by Terence Parr
**
*/

/*Compiling notes:
**Compile grammar with ANTLR4
**This will generate a Parser, Lexer, Listener, and BaseListener Java file as well as Lexer and Listener token files. All with Little in front. (pg.25)
**TODO verify this after compiling the grammar
**$ antlr4 Little.g4
**Compile Driver with the grammar. (pg.29)
**$ javac Little*.java Driver.java
**$ java Driver < [file]
*/

//import ANTLR runtime libraries
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
//import library to help with file reading
import java.io.*;
//import the stack library, may be useful for the Parser
import java.util.Stack;

//Beginning of progran
public class Driver{
	//main

	public static void main(String[] args) throws Exception{

		//Referencing page 28 of the Definitive ANTLR4 guide
		//Create a lexer that feeds off of CharStream from System.in
		LittleLexer lexer = new LittleLexer(CharStreams.fromStream(System.in));
			
		//Create a buffer of tokens pulled from the lexer
		CommonTokenStream tokens = new CommonTokenStream(lexer);

		//Step One: Print Tokens and Type
		//Vocabulary vocabulary = lexer.getVocabulary();
		//printTokens(tokens, vocabulary);		


		LittleParser parser = new LittleParser(tokens);
	
		
		//Step Two: Indicate whether the input string is valid
		//parser.removeErrorListeners(); //removes ConsoleErrorListener, which prints to stderr 
		//parser.addErrorListener(new BaseErrorListener()); //replaces it our desired BaseErrorListener
		//ParseTree tree = parser.program();	
		//if (parser.getNumberOfSyntaxErrors() == 0) {
		//	System.out.println("Accepted");	
		//}
		//else {
		//	System.out.println("Not accepted");
		//}		
	        
		
		//Step 3: Symbol Tables
		SwoopTableBuilder listener = new SwoopTableBuilder();
		new ParseTreeWalker().walk(listener, parser.program());

		//From here, we probably need to create a SymbolTable class and build it in OspreyListener
		//SymbolTable symTable = listener.getSymbolTable();
		//print(symTable);

		String[] tinyCode = listener.getTinyCode();

		for(int i = 0; i < tinyCode.length; i++) {
			System.out.println(tinyCode[i]);
		}

		return;

	}//end main
	
	//Step One: Lexer/Scanner
	//method for printing tokens to a file.
	static void printTokens(CommonTokenStream tokens, Vocabulary vocabulary) throws Exception{
		
		for (int i = 0; i < tokens.getNumberOfOnChannelTokens() - 1; i++) {
			
			Token tempToken = tokens.LT(1 + i);
			System.out.println("Token Type: " + vocabulary.getSymbolicName(tempToken.getType()));
			System.out.println("Value: " + tempToken.getText());

		}

	}//end printTokens
	
	
}//end Driver
