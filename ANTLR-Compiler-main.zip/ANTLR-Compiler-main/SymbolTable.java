import java.util.HashMap;
import java.util.ArrayList;

public class SymbolTable{

	private String scope;
	private HashMap<String, SymbolAttributes> symbolTable; 
	public ArrayList<String> symbolNames;



	public SymbolTable(String scope) {
		//System.out.println("DEV: " + scope);
		this.scope = scope;

		this.symbolTable = new HashMap<String, SymbolAttributes>();
		this.symbolNames = new ArrayList<String>();

	}

	public String getScope() {
		return this.scope;
	}

	public SymbolAttributes get(String symbol) {
		return this.symbolTable.get(symbol);
	}	

	public void addSymbol(String symbolName, SymbolAttributes attributes) {
		if (this.symbolTable.containsKey(symbolName)) {
			System.out.println("DECLARATION ERROR " + symbolName);
			System.exit(0);
		}

		//System.out.println("DEV: New symbol " + symbolName);

		this.symbolTable.put(symbolName, attributes);
		this.symbolNames.add(symbolName);
	
		return;
	}


	/*
	 *Prints contents of table as per the step 3 format
	 */
	public void printTableInOrder() {
		String currSymbol = null;
		SymbolAttributes currAttributes;

		System.out.println("Symbol table " + this.scope);
		
		if(this.symbolNames.size() == 0) {
			System.out.println();	
			return;
		}

		for (int i = 0; i < this.symbolNames.size(); i++) {
			currSymbol = symbolNames.get(i);
			currAttributes = symbolTable.get(currSymbol);
			
			System.out.print("name " + currSymbol);
			System.out.print(" type " + currAttributes.getType());
			if (currAttributes.getType() == "STRING")
				System.out.println(" value " + currAttributes.getValue());
			else
				System.out.println();
		}
		

		System.out.println();

		return;
	}


}

class SymbolAttributes {
	String type;
	String value;

	public SymbolAttributes(String type, String value) {
		this.type = type;
		this.value = value;
	}

	//Don't need setters: Strings are immutablem, number values are not stored

	public String getType() {
		return this.type;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
