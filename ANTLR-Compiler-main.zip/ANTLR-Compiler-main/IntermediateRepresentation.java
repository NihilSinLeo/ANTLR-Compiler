import java.util.ArrayList;

/**
 * A class which is meant to serve as an intermediate 
 * representation of a Little program, adjusted to the 
 * needs of this project. 
 *
 *
 */
public class IntermediateRepresentation {
	private SymbolTable globalTable;
	private ArrayList<String[]> functionStatements; //each held string array of 3AC/tiny String 
				        		//statements corresponds to 1 Little line
	private ArrayList<String> tinyCode; 							
	
	public IntermediateRepresentation() {
		this.globalTable = null;
		this.functionStatements = new ArrayList<String[]>();	
		this.tinyCode = new ArrayList<String>();
		
		return;
	}

	public void setGlobalTable(SymbolTable globalTableIn) {
		this.globalTable = globalTableIn;
		
		return;
	}


	public SymbolTable getGlobalTable() {
		return this.globalTable;
	}


	public void addStatement(String[] statementIn) {
		functionStatements.add(statementIn);	

		return;
	}

	public String[] prepareTinyCode() {
		this.tinyCode = new ArrayList<String>();

		for (int i = 0; i < this.globalTable.symbolNames.size(); i++) {  
			if (this.globalTable.get(this.globalTable.symbolNames.get(i)).getType().equals("STRING")) continue;
			tinyCode.add("var " + this.globalTable.symbolNames.get(i));
		}

		for (int i = 0; i < functionStatements.size(); i++) {
			for (int j = 0; j < functionStatements.get(i).length; j++) {
				if (functionStatements.get(i)[j] != "NULL")
					tinyCode.add(functionStatements.get(i)[j]);
			}
		}

		tinyCode.add("sys halt");

		String[] codeOut = new String[this.tinyCode.size()];
		codeOut = tinyCode.toArray(codeOut);

		return codeOut;
	}


}	
