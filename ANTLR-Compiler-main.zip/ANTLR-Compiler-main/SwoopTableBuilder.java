import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.ParserRuleContext;
import java.util.Stack;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class implements the empty LittleListener interface, implementing
 * changes as neccessary to facilitate the production and printing of a 
 * symbol table as per the Project Step 3 Requirements.
 */
public class SwoopTableBuilder extends LittleBaseListener {
	private Stack<SymbolTable> symbolTableStack;
	private ArrayList<SymbolTable> symbolTableList; //Structure to easily print tables in order
	private SymbolTable currentTable;
	private SymbolTable tempTable;

	//these will have to be changed/worked around to get the read and write list
	private boolean ignoreIDList; //to ignore adding symbols in read/write to the symbol table
	private boolean emptyElse;
    	private boolean readStmt;

	//Read and Write tables
	private ArrayList<String> readTable;
	private ArrayList<String> writeTable;
	
	private int blockCounter = 1; //counts scope for symbol tables labelled 'BLOCK X'

	private Stack<String> exprStack;
	private int opCount; //gets number of operands in the RHS, distinguishes assignment and operations
	private int tempCounter = 1; //counts current temp labeled '$TX' for 
				     //naively generated 3AC in expression
	private int registerCounter = 0; //counts current temp labeled 'rX' for 
				     	//naively generated tiny in expression

	private String varType = "MISTAKE";//debug for variables declared using id_list
	
	private IntermediateRepresentation programIR;


	public SwoopTableBuilder() {
		this.symbolTableStack = new Stack<SymbolTable>();
		this.symbolTableList = new ArrayList<SymbolTable>();
		this.programIR = new IntermediateRepresentation();
		this.currentTable = null;
		this.ignoreIDList = false;
		this.emptyElse = false;
		this.readStmt = false;
	}

	public String[] getTinyCode() {
		return this.programIR.prepareTinyCode();
	}

	
	/**
	 * Responsible for printing all tables once the program is fully parsed
	 */
	@Override
	public void exitProgram(LittleParser.ProgramContext ctx) {
		
		//used to print symbol tables in step 3
		/*
		for(int i = 0; i < symbolTableList.size(); i++) {
			//System.out.println(symbolTableList.get(i));
			symbolTableList.get(i).printTableInOrder();
		}
		*/

		return;
	}


	/*
	 *
	 */
	@Override
	public void enterRead_stmt(LittleParser.Read_stmtContext ctx) {
		ignoreIDList = true;
		readStmt = true;
		readTable = new ArrayList<String>();
			
		return;
	}

	/*
	 *
	 */
	@Override
	public void exitRead_stmt(LittleParser.Read_stmtContext ctx) {
		ignoreIDList = false;
		readStmt = false;


		//Generate tiny code for each read and push onto the function table
		String currVar, type;
		String[] statement = new String[readTable.size()];
		//holds Strings of equivalent code for current Little line
		for(int i = 0; i < statement.length; i++){
			currVar = readTable.get(i);
			
			type = this.programIR.getGlobalTable().get(currVar).getType();
			if(type.equals("STRING")){
				statement[i] = "sys reads " + currVar;
			}
			else if(type.equals("INT")){
				statement[i] = "sys readi " + currVar;
			}
			else{//float
				statement[i] = "sys readr " + currVar;
			}
		}
		
		this.programIR.addStatement(statement);

		return;
	}

	/*
	 *
	 */
	@Override
	public void enterWrite_stmt(LittleParser.Write_stmtContext ctx) {
		ignoreIDList = true;
		writeTable = new ArrayList<String>();	
			
		return;
	}
	
	/*
	 *
	 */
	@Override
	public void exitWrite_stmt(LittleParser.Write_stmtContext ctx) {
		ignoreIDList = false;

		//Generate tiny code for each write and push onto the function table
		String currVar, type;
		String[] statement = new String[writeTable.size()];
		//holds Strings of equivalent code for current Little line
		for(int i = 0; i < statement.length; i++){
			currVar = writeTable.get(i);
			
			type = this.programIR.getGlobalTable().get(currVar).getType();
			if(type.equals("STRING")){
				statement[i] = "sys writes " + currVar;
			}
			else if(type.equals("INT")){
				statement[i] = "sys writei " + currVar;
			}
			else{//float
				statement[i] = "sys writer " + currVar;
			}
		}
			
		this.programIR.addStatement(statement);

		
		return;
	}




	/**
	 * Initializes the "GLOBAL" symbol table 
	 */
	@Override
	public void enterProgram(LittleParser.ProgramContext ctx) { 
		tempTable = new SymbolTable("GLOBAL");

		symbolTableList.add(tempTable);
		this.symbolTableStack.push(tempTable);
		this.currentTable = this.symbolTableStack.peek();

		//System.out.println("Symbol table GLOBAL");

		return;
	}


	
	/**
	 * Initializes symbol tables tied to functions 
	 */
	@Override 
	public void enterFunc_decl(LittleParser.Func_declContext ctx) {
		tempTable = new SymbolTable(ctx.id().IDENTIFIER().getText());

		this.programIR.setGlobalTable(symbolTableList.get(0));

		symbolTableList.add(tempTable);
		this.symbolTableStack.push(tempTable);
		this.currentTable = this.symbolTableStack.peek();

		//System.out.println("Symbol table <funcNamfuncName>");

		return;
	}
	@Override //prints and pops symbol table
	public void exitFunc_decl(LittleParser.Func_declContext ctx) {
		this.symbolTableStack.pop();

		return;	
	}



	/**
	 * Initializes symbol tables tied to if statements
	 */
	@Override
	public void enterIf_stmt(LittleParser.If_stmtContext ctx) {
		//System.out.println("DEV IF:" + blockCounter);
		tempTable = new SymbolTable("BLOCK " + blockCounter++);
	
		symbolTableList.add(tempTable);	
		this.symbolTableStack.push(tempTable);
		this.currentTable = this.symbolTableStack.peek();

		//System.out.println("Symbol table BLOCK <blockCounter>");

		return;
	}
	@Override //prints and pops symbol table
	public void exitIf_stmt(LittleParser.If_stmtContext ctx) {		
		this.symbolTableStack.pop();

		return;	
	}



	/**
	 * Initializes symbol tables tied to else statements 	
	 */
	@Override
	public void enterElse_part(LittleParser.Else_partContext ctx) {
		if(ctx.children.size() == 1) {
			emptyElse = true;
			return;	
		}

		//System.out.println("DEV ELSE:" + blockCounter);
		tempTable = new SymbolTable("BLOCK " + blockCounter++);	

		symbolTableList.add(tempTable);
		this.symbolTableStack.push(tempTable);
		this.currentTable = this.symbolTableStack.peek();

		//System.out.println("Symbol table BLOCK <blockCounter>");

		return;	
	}
	@Override //prints and pops symbol table
	public void exitElse_part(LittleParser.Else_partContext ctx) {	
		if(emptyElse) { 
			emptyElse = false;
			return;
		}

		this.symbolTableStack.pop();

		return;	
	}


	/**
	 * Initializes symbol tables tied to while statements 
	 */
	@Override
	public void enterWhile_stmt(LittleParser.While_stmtContext ctx) {
		tempTable = new SymbolTable("BLOCK " + blockCounter++);	

		symbolTableList.add(tempTable);
		this.symbolTableStack.push(tempTable);
		this.currentTable = this.symbolTableStack.peek();

		//System.out.println("Symbol table BLOCK <blockCounter>");

		return;
	}
	@Override //prints and pops symbol table
	public void exitWhile_stmt(LittleParser.While_stmtContext ctx) 	{		
		this.symbolTableStack.pop();

		return;
	}





	/**
	 * Adds a String item to the current symbol table 
	 */
	@Override
	public void enterString_decl(LittleParser.String_declContext ctx) {
		if (ignoreIDList) return;

		this.currentTable.addSymbol(ctx.id().IDENTIFIER().getText(), new SymbolAttributes("STRING", ctx.str().STRINGLITERAL().getText()));

		String[] statement = {"str " + ctx.id().IDENTIFIER().getText() + " " + ctx.str().STRINGLITERAL().getText()};
		this.programIR.addStatement(statement);

		return;
	}





	/**
	 * Indicates the type of the symbols in the following id_list and potential id_tail(s)
	 */
	@Override
	public void enterVar_decl(LittleParser.Var_declContext ctx) { 

		this.varType = ctx.var_type().getText();
		
		return;
	}



	/**
	 * Adds an int or float item to the current symbol table
	 */
	@Override
	public void enterId_list(LittleParser.Id_listContext ctx) {
		if (ignoreIDList) {
			if(readStmt)//In a read statement
			{
				this.readTable.add(ctx.id().IDENTIFIER().getText());
			}
			else//In a write Statement
			{
				this.writeTable.add(ctx.id().IDENTIFIER().getText());
			}
			return;
		}
		    

		this.currentTable.addSymbol(ctx.id().IDENTIFIER().getText(), new SymbolAttributes(varType, null));
	
		return;
	}



	/**
	 * Adds an int or float item to the current symbol table
	 */
	@Override
	public void enterId_tail(LittleParser.Id_tailContext ctx) {
		if (ignoreIDList)
		{
			if(ctx.id() == null) return;
			if(readStmt)
			{
				this.readTable.add(ctx.id().IDENTIFIER().getText());
			}
			else
			{
				this.writeTable.add(ctx.id().IDENTIFIER().getText());
			}
			return;
		}
		 

		if(ctx.id() == null) return;

		this.currentTable.addSymbol(ctx.id().IDENTIFIER().getText(), new SymbolAttributes(varType, null));
	
		return;
	}



	/**
	 * Adds an int or float item declared as a parameter to the current symbol table
	 */
	@Override
	public void enterParam_decl(LittleParser.Param_declContext ctx) {
		if (ignoreIDList) return;

		this.currentTable.addSymbol(ctx.id().IDENTIFIER().getText(), new SymbolAttributes(ctx.var_type().getText(), null));
	
		return;
	}

///////////////////////////////////////////////////BELOW: Methods used to implement assignment expression 3AC generation
	/**
	 * Initializes a new exprStack
	 */
	@Override 
	public void enterAssign_stmt(LittleParser.Assign_stmtContext ctx) { 
		exprStack = new Stack<String>();

		exprStack.push(ctx.assign_expr().id().IDENTIFIER().getText()); //LHS is first thing pushed to exprStack

	
		return;
	}



	/**
	 * Begins conversion of exprStack to equivalent 3AC for the line
	 */
	@Override 
	public void exitAssign_stmt(LittleParser.Assign_stmtContext ctx) { 
		String LHS, RHS, X1, X2, OP, type;
		String[] statement = new String[4]; //holds Strings of equivalent tiny for current Little line
		int tempi = 0, tempi2 = 0;
		double tempr = 0, tempr2 = 0;
	       	boolean x1const = false, x2const = false;
		String temps;

		if (opCount == 1) { //direct assignment: LHS = RHS
			RHS = exprStack.pop();
			LHS = exprStack.pop();

			statement[0] = "move " + RHS + " r" + registerCounter;
			statement[1] = "move r" + registerCounter++ + " " + LHS;
			statement[2] = "NULL";
			statement[3] = "NULL";

			this.programIR.getGlobalTable().get(LHS).setValue(RHS);

		}

		else { //arithmetic operation: LHS = X1 OP X2

			X2 = exprStack.pop();
			OP = exprStack.pop();
			X1 = exprStack.pop();
			LHS = exprStack.pop();

			switch(OP) { //adjusts OP to proper format
				case "+":
					OP = "add";
					break;
				case "-":
					OP = "sub";
					break;
				case "*":
					OP = "mul";
					break;
				case "/":
					OP = "div";
					break;
			}

			type = this.programIR.getGlobalTable().get(LHS).getType();

			if (type.equals("FLOAT")) {
				/*
				try {
					tempr = Double.parseDouble(X1);
					x1const = true;
					tempr2 = Double.parseDouble(X2);
					x2const = true;	
				}
				catch (Exception e) {
					if (x1const) {}
					else {
						temps = this.programIR.getGlobalTable().get(X1).getValue();
						if (temps == null) x1const = false;
					        else {
							x1const = true;	
							tempr = Double.parseDouble(temps);	
						}
					}
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X2);
					if (tempAtr == null) x2const = false;
					else if (tempAtr.getValue() == null) x2const = false;
					else {
						x2const = true;
						tempr2 = Double.parseDouble(tempAtr.getValue());
					}
				}
				*/

				try {
					tempr = Double.parseDouble(X1);
					x1const = true;
				}
				catch (Exception e) {
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X1);
					if (tempAtr == null) x1const = false;
					else if (tempAtr.getValue() == null) x1const = false;
					else {
						x1const = true;
						tempr = Double.parseDouble(tempAtr.getValue());
					}
				}
				try {
					tempr2 = Double.parseDouble(X2);
					x2const = true;
				}
				catch (Exception e) {
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X2);
					if (tempAtr == null) x2const = false;
					else if (tempAtr.getValue() == null) x2const = false;
					else {
						x2const = true;
						tempr2 = Double.parseDouble(tempAtr.getValue());
					}
				}
			
				if (x1const && x2const) {

					switch(OP) { //adjusts OP to proper format
						case "add":
							statement[0] = "move " + (tempr + tempr2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;	
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempr+tempr2));			
							break;
						case "sub":
							statement[0] = "move " + (tempr - tempr2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempr-tempr2));
							break;
						case "mul":
							statement[0] = "move " + (tempr * tempr2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempr*tempr2));
							break;
						case "div":
							statement[0] = "move " + (tempr / tempr2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempr/tempr2));
							break;
					}
				
					statement[2] = "NULL";
					statement[3] = "NULL";		
					
					//System.out.println(tempr + OP + tempr2);
					
					this.programIR.addStatement(statement);
					opCount = 0;

					return;
				}
			}
			else { //type is INT 
			       	/*	
				try {
					tempi = Integer.parseInt(X1);
					x1const = true;
					tempi2 = Integer.parseInt(X2);
					x2const = true;	
				}
				catch (Exception e) {
					if (x1const) {}
					else {
						temps = this.programIR.getGlobalTable().get(X1).getValue();
						if (temps == null) x1const = false;
					        else {
							x1const = true;	
							tempi = Integer.parseInt(temps);	
						}
					}
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X2);
					if (tempAtr == null) x2const = false;
					else if (tempAtr.getValue() == null) x2const = false;
					else {
						x2const = true;
						tempi2 = Integer.parseInt(tempAtr.getValue());
					}
				}
				*/

				try {
					tempi = Integer.parseInt(X1);
					x1const = true;
				}
				catch (Exception e) {
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X1);
					if (tempAtr == null) x1const = false;
					else if (tempAtr.getValue() == null) x1const = false;
					else {
						x1const = true;
						tempi = Integer.parseInt(tempAtr.getValue());
					}
				}
				try {
					tempi2 = Integer.parseInt(X2);
					x2const = true;
				}
				catch (Exception e) {
					SymbolAttributes tempAtr = this.programIR.getGlobalTable().get(X2);
					if (tempAtr == null) x2const = false;
					else if (tempAtr.getValue() == null) x2const = false;
					else {
						x2const = true;
						tempi2 = Integer.parseInt(tempAtr.getValue());
					}
				}

				if (x1const && x2const) {

					switch(OP) { //adjusts OP to proper format
						case "add":
							statement[0] = "move " + (tempi + tempi2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;	
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempi+tempi2));			
							break;
						case "sub":
							statement[0] = "move " + (tempi - tempi2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempi-tempi2));
							break;
						case "mul":
							statement[0] = "move " + (tempi * tempi2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempi*tempi2));
							break;
						case "div":
							statement[0] = "move " + (tempi / tempi2) + " r" + registerCounter;
							statement[1] = "move r" + registerCounter++ + " " + LHS;
							this.programIR.getGlobalTable().get(LHS).setValue(String.valueOf(tempi/tempi2));
							break;
					}
				
					statement[2] = "NULL";
					statement[3] = "NULL";	
					
					//System.out.println(tempi + OP + tempi2);
					
					this.programIR.addStatement(statement);
					opCount = 0;

					return;
				}
			}



			if (type.equals("FLOAT")) {
				statement[0] = "move " + X1 + " r" + registerCounter;
				try {
					tempr = Double.parseDouble(X2);
					statement[1] = "move " + tempr + " r" + ++registerCounter;
					statement[2] = OP + "r r" + registerCounter + " r" + (registerCounter - 1);
				        statement[3] = "move r" + (registerCounter++ - 1) + " " + LHS;	
				}
				catch (Exception e) {
					statement[1] = OP + "r " + X2 + " r" + registerCounter;
					statement[2] = "move r" + registerCounter++ + " " + LHS;
					statement[3] = "NULL";
				}
			}
			else { //type == INT
				statement[0] = "move " + X1 + " r" + registerCounter;
				try {
					tempi = Integer.parseInt(X2);
					statement[1] = "move " + tempi + " r" + ++registerCounter;
					statement[2] = OP + "i r" + registerCounter + " r" + (registerCounter - 1);
				        statement[3] = "move r" + (registerCounter++ - 1) + " " + LHS;	
				}
				catch (Exception e) {
					statement[1] = OP + "i " + X2 + " r" + registerCounter;
					statement[2] = "move r" + registerCounter++ + " " + LHS;
					statement[3] = "NULL";
				}
			}

		}

		this.programIR.addStatement(statement);

		opCount = 0; //resets for next expression

		return;
	}


	/**
	 * Adds operand to exprStack, or skips in the case of a recursive
	 * call to expr 
	 */
	@Override 
	public void enterPrimary(LittleParser.PrimaryContext ctx) { 
		if (ctx.getChildCount() == 3) return; //if: primary -> ( expr )
						      
		opCount++; 

		if (ctx.getChild(0).getChildCount() == 0) { //operand is int/float literal
			exprStack.push(ctx.getChild(0).getText());
		}
		else { //operand is variable
			exprStack.push(ctx.getChild(0).getChild(0).getText());
		}
		
		return;
	}

	/**
	 * Adds the operation symbol to the stack, indicating which 
	 * 3AC instruction to use 
	 */
	@Override 
	public void enterAddop(LittleParser.AddopContext ctx) { 
      		exprStack.push(ctx.getText()); //push + or -
	
		return;
	}



	/**
	 * Adds the operation symbol to the stack, indicating which 
	 * 3AC instruction to use 
	 */
	@Override 
	public void enterMulop(LittleParser.MulopContext ctx) {
      		exprStack.push(ctx.getText()); //push * or /	

		return;
	}
	
///////////////////////////////////////////////////ABOVE: Methods used to implement assignment expression 3AC generation
}



		
